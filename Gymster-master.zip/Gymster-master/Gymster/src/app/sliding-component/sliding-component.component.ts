import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sliding-component',
  templateUrl: './sliding-component.component.html',
  styleUrls: ['./sliding-component.component.css']
})
export class SlidingComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
